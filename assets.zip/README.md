# pegipegi-slicing
Desain baru pegi pegi hehehe <br>
figma : https://www.figma.com/file/gPTvpdbCDaGYgDzIpwjhlY/Pegipegi?node-id=0%3A1
